#!/usr/bin/env python3
"""
LQR Gain Computation for Crazyflie Controller

This script computes the LQR gain matrix K for the Crazyflie hover controller
and outputs it in C format for direct copy-paste into controller_lqr.c.

Usage:
    python compute_lqr_gains.py

The computed gains are saved to:
    - lqr_gains.h (C header format)
    - lqr_gains.txt (human readable)
    
Author: Claude
Date: 2025
"""

import numpy as np
from scipy.linalg import solve_continuous_are
import sys

# ============================================================================
# Physical Parameters (Crazyflie 2.1)
# ============================================================================

MASS = 0.027        # kg
GRAVITY = 9.81      # m/s^2
IXX = 1.6e-5        # kg·m² (moment of inertia)
IYY = 1.6e-5        # kg·m²
IZZ = 2.9e-5        # kg·m²

# Scaling constants (must match controller_lqr.h)
THRUST_SCALE = 1.0      # N per normalized unit
MOMENT_SCALE = 2.0e-4   # N·m per normalized unit

# Damping coefficients (from linearized model)
KV_XY = 2.0     # Horizontal velocity damping (1/s)
KV_Z = 3.0      # Vertical velocity damping (1/s)
KP_ATT = 10.0   # Angular rate damping (1/s)


def build_continuous_model():
    """
    Build the continuous-time linearized state-space model.
    
    State: x = [px, py, pz, vx, vy, vz, roll, pitch, yaw, p, q, r]
    Input: u = [delta_thrust, tau_roll, tau_pitch, tau_yaw]
    
    Returns:
        A: 12x12 state matrix
        B: 12x4 input matrix
    """
    nx, nu = 12, 4
    
    A = np.zeros((nx, nx))
    
    # Position dynamics: ṗ = v
    A[0, 3] = 1.0  # ṗx = vx
    A[1, 4] = 1.0  # ṗy = vy
    A[2, 5] = 1.0  # ṗz = vz
    
    # Velocity dynamics (linearized near hover)
    A[3, 7] = GRAVITY   # v̇x = g·θ (pitch → X acceleration)
    A[4, 6] = -GRAVITY  # v̇y = -g·φ (roll → Y acceleration)
    # v̇z controlled by thrust
    
    # Attitude kinematics
    A[6, 9] = 1.0    # φ̇ = p
    A[7, 10] = 1.0   # θ̇ = q
    A[8, 11] = 1.0   # ψ̇ = r
    
    # Damping terms
    A[3, 3] = -KV_XY    # vx damping
    A[4, 4] = -KV_XY    # vy damping
    A[5, 5] = -KV_Z     # vz damping
    A[9, 9] = -KP_ATT   # p damping
    A[10, 10] = -KP_ATT # q damping
    A[11, 11] = -KP_ATT # r damping
    
    # Input matrix
    B = np.zeros((nx, nu))
    B[5, 0] = THRUST_SCALE / MASS    # Thrust → v̇z
    B[9, 1] = MOMENT_SCALE / IXX     # τx → ṗ (roll rate)
    B[10, 2] = MOMENT_SCALE / IYY    # τy → q̇ (pitch rate)
    B[11, 3] = MOMENT_SCALE / IZZ    # τz → ṙ (yaw rate)
    
    return A, B


def compute_lqr_gains(Q=None, R=None, verbose=True):
    """
    Compute LQR gains by solving the continuous-time algebraic Riccati equation.
    
    Args:
        Q: State cost matrix (12x12). Default uses tuned values.
        R: Input cost matrix (4x4). Default uses tuned values.
        verbose: Print debug info
        
    Returns:
        K: 4x12 LQR gain matrix
        P: Solution to CARE
    """
    A, B = build_continuous_model()
    
    if Q is None:
        # Default Q matrix - tuned for hover stability
        Q = np.diag([
            500.0, 500.0, 20.0,    # Position weights [px, py, pz]
            40.0, 40.0, 15.0,      # Velocity weights [vx, vy, vz]
            30.0, 30.0, 2.0,       # Attitude weights [roll, pitch, yaw]
            6.0, 6.0, 3.0          # Angular rate weights [p, q, r]
        ])
    
    if R is None:
        # Default R matrix - tuned for smooth control
        R = np.diag([
            800.0,      # Thrust cost
            1500.0,     # Roll moment cost
            1500.0,     # Pitch moment cost
            20000.0     # Yaw moment cost (high = weak yaw control)
        ])
    
    if verbose:
        print("=" * 60)
        print("LQR Gain Computation for Crazyflie")
        print("=" * 60)
        print(f"\nPhysical Parameters:")
        print(f"  Mass:     {MASS*1000:.1f} g")
        print(f"  Gravity:  {GRAVITY:.2f} m/s²")
        print(f"  Ixx/Iyy:  {IXX:.2e} kg·m²")
        print(f"  Izz:      {IZZ:.2e} kg·m²")
        
        print(f"\nCost Matrices:")
        print(f"  Q (diag): {np.diag(Q)}")
        print(f"  R (diag): {np.diag(R)}")
    
    # Solve CARE: A'P + PA - PBR⁻¹B'P + Q = 0
    try:
        P = solve_continuous_are(A, B, Q, R)
        K = np.linalg.inv(R) @ (B.T @ P)
    except Exception as e:
        print(f"ERROR: Failed to solve CARE: {e}")
        return None, None
    
    if verbose:
        print(f"\nLQR Gain Matrix K (4x12):")
        print_matrix(K, "K")
        
        # Verify closed-loop stability
        A_cl = A - B @ K
        eigs = np.linalg.eigvals(A_cl)
        print(f"\nClosed-loop eigenvalues (should all have negative real part):")
        for i, e in enumerate(eigs):
            stable = "✓" if e.real < 0 else "✗"
            print(f"  λ{i+1} = {e.real:+.4f} {'+' if e.imag >= 0 else ''}{e.imag:.4f}j  {stable}")
        
        all_stable = all(e.real < 0 for e in eigs)
        print(f"\nClosed-loop system: {'STABLE' if all_stable else 'UNSTABLE!'}")
        
        # Key gain analysis
        print(f"\nKey Gains Analysis:")
        print(f"  K[0,2] (thrust←pz):   {K[0,2]:.6f}  (altitude hold)")
        print(f"  K[0,5] (thrust←vz):   {K[0,5]:.6f}  (vertical damping)")
        print(f"  K[1,1] (roll←py):     {K[1,1]:.6f}  (Y position → roll)")
        print(f"  K[1,6] (roll←φ):      {K[1,6]:.6f}  (roll stabilization)")
        print(f"  K[2,0] (pitch←px):    {K[2,0]:.6f}  (X position → pitch)")
        print(f"  K[2,7] (pitch←θ):     {K[2,7]:.6f}  (pitch stabilization)")
    
    return K, P


def print_matrix(M, name="M", precision=4):
    """Pretty print a matrix."""
    rows, cols = M.shape
    print(f"\n{name} = [")
    for i in range(rows):
        row_str = "  ["
        for j in range(cols):
            row_str += f"{M[i,j]:+.{precision}f}"
            if j < cols - 1:
                row_str += ", "
        row_str += "]"
        if i < rows - 1:
            row_str += ","
        print(row_str)
    print("]")


def export_to_c_header(K, filename="lqr_gains.h"):
    """
    Export the gain matrix to a C header file.
    
    Args:
        K: 4x12 gain matrix
        filename: Output filename
    """
    with open(filename, 'w') as f:
        f.write("/**\n")
        f.write(" * @file lqr_gains.h\n")
        f.write(" * @brief Pre-computed LQR gains for Crazyflie controller\n")
        f.write(" * \n")
        f.write(" * Auto-generated by compute_lqr_gains.py\n")
        f.write(" * DO NOT EDIT MANUALLY\n")
        f.write(" * \n")
        f.write(" * To regenerate: python compute_lqr_gains.py\n")
        f.write(" */\n\n")
        f.write("#ifndef __LQR_GAINS_H__\n")
        f.write("#define __LQR_GAINS_H__\n\n")
        
        f.write("/**\n")
        f.write(" * LQR Gain Matrix K (4x12)\n")
        f.write(" * \n")
        f.write(" * State order:  [px, py, pz, vx, vy, vz, roll, pitch, yaw, p, q, r]\n")
        f.write(" * Input order:  [thrust, roll_moment, pitch_moment, yaw_moment]\n")
        f.write(" * \n")
        f.write(" * Cost matrices:\n")
        f.write(" *   Q = diag([500, 500, 20, 40, 40, 15, 30, 30, 2, 6, 6, 3])\n")
        f.write(" *   R = diag([800, 1500, 1500, 20000])\n")
        f.write(" */\n")
        f.write("static const float LQR_K[4][12] = {\n")
        
        labels = ["Thrust", "Roll moment", "Pitch moment", "Yaw moment"]
        state_labels = ["px", "py", "pz", "vx", "vy", "vz", 
                       "roll", "pitch", "yaw", "p", "q", "r"]
        
        for i in range(4):
            f.write(f"    // Row {i}: {labels[i]} gains\n")
            f.write(f"    // {' '.join([f'{s:>8s}' for s in state_labels])}\n")
            f.write("    {")
            for j in range(12):
                val = K[i, j]
                # Use scientific notation for very small numbers
                if abs(val) < 1e-6:
                    f.write(f"{0.0:>9.4f}f")
                else:
                    f.write(f"{val:>9.4f}f")
                if j < 11:
                    f.write(",")
            f.write("}")
            if i < 3:
                f.write(",")
            f.write("\n")
        
        f.write("};\n\n")
        f.write("#endif // __LQR_GAINS_H__\n")
    
    print(f"\n✓ C header saved to: {filename}")


def export_to_text(K, filename="lqr_gains.txt"):
    """Export gains to human-readable text file."""
    with open(filename, 'w') as f:
        f.write("LQR Gains for Crazyflie Controller\n")
        f.write("=" * 60 + "\n\n")
        
        f.write("State vector (12 states):\n")
        f.write("  x = [px, py, pz, vx, vy, vz, roll, pitch, yaw, p, q, r]\n\n")
        
        f.write("Control input (4 inputs):\n")
        f.write("  u = [thrust_delta, roll_moment, pitch_moment, yaw_moment]\n\n")
        
        f.write("Gain Matrix K (4x12):\n")
        f.write("-" * 60 + "\n")
        
        np.savetxt(f, K, fmt='%+.6f', delimiter=', ')
        
        f.write("-" * 60 + "\n\n")
        
        f.write("Key gains:\n")
        f.write(f"  K[0,2] (thrust ← pz):   {K[0,2]:+.6f}\n")
        f.write(f"  K[0,5] (thrust ← vz):   {K[0,5]:+.6f}\n")
        f.write(f"  K[1,1] (roll ← py):     {K[1,1]:+.6f}\n")
        f.write(f"  K[1,6] (roll ← roll):   {K[1,6]:+.6f}\n")
        f.write(f"  K[2,0] (pitch ← px):    {K[2,0]:+.6f}\n")
        f.write(f"  K[2,7] (pitch ← pitch): {K[2,7]:+.6f}\n")
    
    print(f"✓ Text file saved to: {filename}")


def test_with_different_Q_R():
    """Test different Q/R combinations for tuning."""
    print("\n" + "=" * 60)
    print("Testing Different Q/R Configurations")
    print("=" * 60)
    
    configs = [
        # (name, Q_diag, R_diag)
        ("Default", 
         [500, 500, 20, 40, 40, 15, 30, 30, 2, 6, 6, 3],
         [800, 1500, 1500, 20000]),
        
        ("Aggressive XY",
         [1000, 1000, 20, 60, 60, 15, 30, 30, 2, 6, 6, 3],
         [600, 1000, 1000, 20000]),
        
        ("Smooth", 
         [200, 200, 20, 30, 30, 15, 20, 20, 2, 4, 4, 3],
         [1200, 2000, 2000, 20000]),
        
        ("Altitude Focus",
         [300, 300, 100, 30, 30, 40, 20, 20, 2, 4, 4, 3],
         [500, 1500, 1500, 20000]),
    ]
    
    for name, Q_diag, R_diag in configs:
        print(f"\n--- {name} ---")
        Q = np.diag(Q_diag)
        R = np.diag(R_diag)
        K, _ = compute_lqr_gains(Q, R, verbose=False)
        if K is not None:
            print(f"  K[0,2]={K[0,2]:.4f} K[1,1]={K[1,1]:.4f} K[2,0]={K[2,0]:.4f}")


def main():
    """Main entry point."""
    # Compute default gains
    K, P = compute_lqr_gains()
    
    if K is None:
        print("ERROR: Failed to compute gains!")
        sys.exit(1)
    
    # Export to files
    export_to_c_header(K)
    export_to_text(K)
    
    # Optional: test different configurations
    # test_with_different_Q_R()
    
    print("\n" + "=" * 60)
    print("Done! Copy lqr_gains.h content to controller_lqr.c")
    print("=" * 60)


if __name__ == "__main__":
    main()
