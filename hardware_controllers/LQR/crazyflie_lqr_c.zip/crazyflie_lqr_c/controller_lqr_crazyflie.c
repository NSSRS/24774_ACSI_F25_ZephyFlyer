/**
 * @file controller_lqr_crazyflie.c
 * @brief Integration example for Crazyflie firmware
 * 
 * This file shows how to integrate the LQR controller with the 
 * Crazyflie firmware. It implements the controller interface
 * expected by the firmware.
 * 
 * To integrate into Crazyflie firmware:
 * 1. Copy controller_lqr.h and controller_lqr.c to src/modules/src/
 * 2. Copy this file to src/modules/src/
 * 3. Add to Makefile or CMakeLists.txt
 * 4. Enable via parameter or menu
 * 
 * @author Claude
 * @date 2025
 */

#include "controller_lqr.h"

// Crazyflie firmware headers (adjust paths as needed)
// #include "stabilizer_types.h"
// #include "commander.h"
// #include "log.h"
// #include "param.h"
// #include "motors.h"

// ============================================================================
// Type definitions (matching Crazyflie firmware)
// ============================================================================

// Uncomment if not using actual firmware headers
#ifndef STABILIZER_TYPES_H
typedef struct {
    float x, y, z;
} point_t;

typedef struct {
    float roll, pitch, yaw;
} attitude_t;

typedef struct {
    float x, y, z;
} velocity_t;

typedef struct {
    float x, y, z;
} acc_t;

typedef struct {
    point_t position;
    velocity_t velocity;
    attitude_t attitude;
    acc_t acc;
    uint32_t timestamp;
} state_t;

typedef struct {
    point_t position;
    velocity_t velocity;
    attitude_t attitude;
    float thrust;
    struct {
        float x, y, z;
    } attitudeRate;
} setpoint_t;

typedef struct {
    float m1, m2, m3, m4;
} motorPower_t;

typedef struct {
    float roll, pitch, yaw;
} sensorData_t;
#endif

// ============================================================================
// Static controller instance
// ============================================================================

static lqr_controller_t lqrCtrl;
static bool isLqrInit = false;

// Logging variables
static float log_posError = 0.0f;
static float log_u0 = 0.0f;
static float log_u1 = 0.0f;
static float log_u2 = 0.0f;

// ============================================================================
// Controller Interface Functions
// ============================================================================

/**
 * @brief Initialize the LQR controller
 * 
 * Called once at startup.
 */
void controllerLqrInit(void) {
    if (isLqrInit) {
        return;
    }
    
    // Initialize with 500Hz control rate and 0.5m hover height
    float dt = 1.0f / 500.0f;
    float hover_height = 0.5f;
    
    lqrControllerInit(&lqrCtrl, dt, hover_height);
    isLqrInit = true;
    
    // Debug print (use DEBUG_PRINT if available)
    // DEBUG_PRINT("LQR Controller initialized\n");
}

/**
 * @brief Test if the LQR controller is initialized
 */
bool controllerLqrTest(void) {
    return isLqrInit && lqrIsInitialized(&lqrCtrl);
}

/**
 * @brief Main controller update function
 * 
 * Called at control loop rate (typically 500Hz or 1000Hz).
 * 
 * @param state Current state estimate from Kalman filter
 * @param setpoint Desired setpoint from commander
 * @param sensors Raw sensor data
 * @param tick Current system tick
 * @return Motor power commands
 */
void controllerLqr(const state_t* state,
                   const setpoint_t* setpoint,
                   const sensorData_t* sensors,
                   const uint32_t tick,
                   motorPower_t* motorPower) {
    (void)sensors;  // Not used directly - state estimate is preferred
    (void)tick;
    
    if (!isLqrInit) {
        motorPower->m1 = 0;
        motorPower->m2 = 0;
        motorPower->m3 = 0;
        motorPower->m4 = 0;
        return;
    }
    
    // Update target from setpoint
    lqrSetTarget(&lqrCtrl, 
                 setpoint->position.x,
                 setpoint->position.y,
                 setpoint->position.z);
    
    // Prepare sensor data structure
    // Note: Using state estimate which already includes filtered velocity
    lqr_sensor_data_t sensorData;
    sensorData.position[0] = state->position.x;
    sensorData.position[1] = state->position.y;
    sensorData.position[2] = state->position.z;
    sensorData.attitude[0] = state->attitude.roll * 3.14159265f / 180.0f;  // deg to rad
    sensorData.attitude[1] = state->attitude.pitch * 3.14159265f / 180.0f;
    sensorData.attitude[2] = state->attitude.yaw * 3.14159265f / 180.0f;
    sensorData.angular_rate[0] = 0.0f;  // Fill from gyro if available
    sensorData.angular_rate[1] = 0.0f;
    sensorData.angular_rate[2] = 0.0f;
    sensorData.timestamp = tick / 1000.0f;  // Convert ms to s
    
    // Alternative: If using state estimate velocity instead of differentiation
    // Override the velocity filter with state estimate
    lqrCtrl.vx_filtered = state->velocity.x;
    lqrCtrl.vy_filtered = state->velocity.y;
    lqrCtrl.vz_filtered = state->velocity.z;
    
    // Compute control
    lqr_motor_output_t output;
    if (lqrControllerUpdate(&lqrCtrl, &sensorData, &output)) {
        // Convert to uint16_t motor commands (0-65535 range in firmware)
        // Our controller outputs 0-600 range, scale accordingly
        float scale = 65535.0f / 600.0f;
        motorPower->m1 = (uint16_t)(output.m1 * scale);
        motorPower->m2 = (uint16_t)(output.m2 * scale);
        motorPower->m3 = (uint16_t)(output.m3 * scale);
        motorPower->m4 = (uint16_t)(output.m4 * scale);
    } else {
        motorPower->m1 = 0;
        motorPower->m2 = 0;
        motorPower->m3 = 0;
        motorPower->m4 = 0;
    }
    
    // Update logging variables
    log_posError = lqrGetPositionError(&lqrCtrl);
    log_u0 = lqrCtrl.u[0];
    log_u1 = lqrCtrl.u[1];
    log_u2 = lqrCtrl.u[2];
}

/**
 * @brief Reset the controller
 */
void controllerLqrReset(void) {
    if (isLqrInit) {
        lqrControllerReset(&lqrCtrl);
    }
}

// ============================================================================
// Alternative: Direct Attitude Control Integration
// ============================================================================

/**
 * @brief Compute desired attitude from position error
 * 
 * This version outputs attitude setpoints that can be fed to the
 * existing attitude controller, rather than directly commanding motors.
 * 
 * @param state Current state
 * @param setpoint Position setpoint
 * @param attSetpoint Output attitude setpoint
 * @param thrust Output collective thrust
 */
void controllerLqrOuterLoop(const state_t* state,
                            const setpoint_t* setpoint,
                            attitude_t* attSetpoint,
                            float* thrust) {
    if (!isLqrInit) {
        attSetpoint->roll = 0.0f;
        attSetpoint->pitch = 0.0f;
        attSetpoint->yaw = 0.0f;
        *thrust = 0.0f;
        return;
    }
    
    // Position error
    float ex = state->position.x - setpoint->position.x;
    float ey = state->position.y - setpoint->position.y;
    float ez = state->position.z - setpoint->position.z;
    
    // Velocity error (assuming setpoint velocity is 0)
    float evx = state->velocity.x;
    float evy = state->velocity.y;
    float evz = state->velocity.z;
    
    // Simple PD position control → attitude setpoint
    // These gains need tuning for your system
    float Kp_xy = 0.5f;
    float Kd_xy = 0.3f;
    float Kp_z = 1.0f;
    float Kd_z = 0.5f;
    
    // Desired accelerations
    float ax_des = -Kp_xy * ex - Kd_xy * evx;
    float ay_des = -Kp_xy * ey - Kd_xy * evy;
    float az_des = -Kp_z * ez - Kd_z * evz;
    
    // Convert to attitude (small angle approximation)
    // ax = g * theta, ay = -g * phi
    float g = 9.81f;
    float pitch_des = ax_des / g;  // rad
    float roll_des = -ay_des / g;  // rad
    
    // Clamp attitude
    float max_angle = 0.3f;  // ~17 degrees
    if (pitch_des > max_angle) pitch_des = max_angle;
    if (pitch_des < -max_angle) pitch_des = -max_angle;
    if (roll_des > max_angle) roll_des = max_angle;
    if (roll_des < -max_angle) roll_des = -max_angle;
    
    // Output (convert to degrees for firmware)
    attSetpoint->roll = roll_des * 180.0f / 3.14159265f;
    attSetpoint->pitch = pitch_des * 180.0f / 3.14159265f;
    attSetpoint->yaw = 0.0f;  // Hold current yaw
    
    // Thrust (in firmware units)
    float hover_thrust = 0.027f * 9.81f;  // mass * g
    float thrust_delta = az_des * 0.027f;  // m * a
    *thrust = (hover_thrust + thrust_delta) * 1000.0f;  // Scale to firmware units
}

// ============================================================================
// Logging and Parameters (Crazyflie firmware integration)
// ============================================================================

/*
 * Uncomment this section when integrating with actual Crazyflie firmware
 */

/*
LOG_GROUP_START(ctrlLQR)
  LOG_ADD(LOG_FLOAT, posErr, &log_posError)
  LOG_ADD(LOG_FLOAT, u0, &log_u0)
  LOG_ADD(LOG_FLOAT, u1, &log_u1)
  LOG_ADD(LOG_FLOAT, u2, &log_u2)
LOG_GROUP_STOP(ctrlLQR)

PARAM_GROUP_START(ctrlLQR)
  PARAM_ADD(PARAM_FLOAT, Ki_z, &lqrCtrl.Ki_z)
  PARAM_ADD(PARAM_FLOAT, Ki_xy, &lqrCtrl.Ki_xy)
  PARAM_ADD(PARAM_FLOAT, alpha_v, &lqrCtrl.alpha_v)
PARAM_GROUP_STOP(ctrlLQR)
*/

// ============================================================================
// Test Code
// ============================================================================

#ifdef LQR_TEST

#include <stdio.h>

int main(void) {
    printf("=== LQR Controller Test ===\n\n");
    
    // Initialize
    controllerLqrInit();
    printf("Controller initialized: %s\n", 
           controllerLqrTest() ? "OK" : "FAIL");
    
    // Set target
    lqrSetTarget(&lqrCtrl, 0.0f, 0.0f, 0.5f);
    printf("Target set to (0, 0, 0.5)\n");
    
    // Simulate a few steps
    lqr_sensor_data_t sensors = {
        .position = {0.0f, 0.0f, 0.3f},  // Below target
        .attitude = {0.0f, 0.0f, 0.0f},
        .angular_rate = {0.0f, 0.0f, 0.0f},
        .timestamp = 0.0f
    };
    
    lqr_motor_output_t output;
    
    for (int i = 0; i < 5; i++) {
        sensors.timestamp = i * 0.002f;
        sensors.position[2] += 0.02f;  // Rising
        
        lqrControllerUpdate(&lqrCtrl, &sensors, &output);
        
        printf("Step %d: pos=(%.3f,%.3f,%.3f) motors=[%.1f,%.1f,%.1f,%.1f] err=%.4f\n",
               i, sensors.position[0], sensors.position[1], sensors.position[2],
               output.m1, output.m2, output.m3, output.m4,
               lqrGetPositionError(&lqrCtrl));
    }
    
    printf("\nTest complete.\n");
    return 0;
}

#endif // LQR_TEST
